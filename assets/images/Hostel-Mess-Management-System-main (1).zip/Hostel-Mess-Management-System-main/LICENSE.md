# QiForge Open Learning License (QOLL-1.0)
Copyright (c) 2025 QiForge Organization

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software, associated files, or related materials (the "Software"),
to use, study, and modify the Software for personal learning, educational,
and non-commercial purposes, subject to the following conditions:

1. Attribution:
   - Proper credit must be given to the QiForge Organization and/or
     respective project contributors when using, displaying, or sharing
     modified versions of the Software.

2. Educational Use Only:
   - The Software is provided primarily for learning and academic
     experimentation. Commercial redistribution or resale of the Software
     or its derivatives requires explicit written consent from QiForge.

3. Prohibition of Misrepresentation:
   - You may not claim, represent, or imply that you are an official member,
     partner, or representative of the QiForge Organization unless
     explicitly authorized.
   - You may not use QiForge’s name, logo, or brand to impersonate the
     organization, its leadership, or affiliated teams.

4. Prohibition of Malicious or Illegal Use:
   - The Software may not be used, modified, or distributed for any
     unlawful purpose or to conduct any form of cybercrime, fraud, or
     activity that harms others in the name of QiForge.

5. Disclaimer of Warranty:
   - The Software is provided "AS IS", without warranty of any kind,
     express or implied, including but not limited to warranties of
     merchantability, fitness for a particular purpose, and noninfringement.
     In no event shall the authors or copyright holders be liable for any
     claim, damages, or other liability arising from the use of the Software.

6. Community Integrity:
   - Users are encouraged to learn, share, and contribute responsibly while
     respecting the collaborative and educational mission of the QiForge
     Organization.

By using or modifying this Software, you agree to abide by the above terms.

QiForge — Learn. Build. Collaborate.
https://qiforge.site
